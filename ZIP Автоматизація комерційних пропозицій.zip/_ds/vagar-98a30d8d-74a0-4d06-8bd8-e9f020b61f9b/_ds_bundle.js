/* @ds-bundle: {"format":4,"namespace":"Vagar_98a30d","components":[],"sourceHashes":{},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.Vagar_98a30d = window.Vagar_98a30d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

})();
