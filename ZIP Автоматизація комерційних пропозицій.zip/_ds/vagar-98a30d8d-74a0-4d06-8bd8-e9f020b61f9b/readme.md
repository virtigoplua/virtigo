# Vagar

Waga i akcesoria do wag

This design system was generated mechanically from the onboarding brand form — no AI was involved. Every token in `styles.css` traces to a form input or a documented default, so it is a faithful starting point, not an interpretation. Edit `styles.css` to retune the look; keep this guide in step with what the CSS actually does.

## How to use this

- Link the one stylesheet from every page — `<link rel="stylesheet" href="styles.css">` (adjust the relative path) — and take every color, font, spacing, radius and shadow from its variables (`var(--color-*)`, `var(--font-*)`, `var(--space-*)`, `var(--radius-*)`, `var(--shadow-*)`). Never hard-code a hex, a font name or a px value the tokens already carry.
- Each color role carries a 100-900 tonal ramp (`--color-neutral-100` … `--color-accent-2-900`) generated in OKLCH on a shared perceptual lightness scale. Use the light steps (100-300) for tinted fills, hovers and subtle borders, 500 as a role base, and the dark steps (700-900) for text on tinted fills and for pressed states.
- For elevation use `--shadow-sm/md/lg` (already tuned to the ground) rather than ad-hoc box-shadows.

## Color

Page ground `#f2f2f3` with text `#1d1f20`, surface `#e9e9ea`, and accents `#0265b7` / `#228ee7`.

The form's brand colors, in the order given, and the role each was assigned (assignment is by documented rules — ground-suitability by luminance, accents by chroma, text by contrast):

- `#0265b7` — primary accent (--color-accent)

## Type

- Headings (--font-heading): Archivo (loaded from Google Fonts by styles.css)
- Body (--font-body): Inter (loaded from Google Fonts by styles.css)

## Assets

- Logo: `assets/logo.jpg` (preview card: `brand/logo.html`)
